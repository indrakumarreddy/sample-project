<div class="mk-subscribe _ width-full">
	<div id="mk-subscribe--message" class="mk-subscribe--message _ block width-full"></div>
	<form action="mk_ajax_subscribe" method="post" class="mk-subscribe--form _ table width-full">
		<div class="mk-subscribe--form-column _ table-cell">
			<input type="text" name="mk-subscribe--email" class="mk-subscribe--email">
			<input type="hidden" name="mk-subscribe--list-id" class="mk-subscribe--list-id">
			<input type="hidden" name="mk-subscribe--optin" class="mk-subscribe--optin">
		</div>
		<div class="mk-subscribe--form-column _ table-cell">
			<button id="mk-subscribe--button" class="mk-subscribe--button _ font-weight-b"> 
				<span></span>
			</button>
		</div>
	</form>
</div>