<?php
extract(shortcode_atts(array(
    'fullwidth' => 'false',
    'fullwidth_content' => 'true',
    'id' => '',
    'column_padding' => 0,
    'padding' => 0,
    'attached' => 'false',
    'visibility' => '',
    'css' => '',
    'animation' => '',
    'equal_columns' => 'false',
    'disable_element' => '',
    'parallax' => '',
    'parallax_image' => '',
    'video_bg_parallax' => '',
    'parallax_speed_bg' => 1.5,
    'video_bg' => '',
    'video_bg_url' => 'https://www.youtube.com/watch?v=lMJXxhRFO1k',
    'parallax_speed_video' => 1.5,
    'el_class' => ''
) , $atts));
Mk_Static_Files::addAssets('vc_row');
